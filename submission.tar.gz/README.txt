Welcome to FIFA 2110!

This is a simple soccer game with a player (you), opponent, referee, and ball.
The objective is to score 5 goals while making sure not to make contact with the referee or the opponent.
You use the arrow keys on your keyboard to move up, down, left, and right across the field.

If you make contact with the ball, you score.
You must score 5 times to win.
If you collide with the opponent 5 times, you lose
If you get 5 red cards, you get sent off and cannot continue the match further.