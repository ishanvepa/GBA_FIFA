/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 messi_title_image messi_title_image.jpg 
 * Time-stamp: Sunday 03/31/2024, 01:52:00
 * 
 * Image Information
 * -----------------
 * messi_title_image.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MESSI_TITLE_IMAGE_H
#define MESSI_TITLE_IMAGE_H

extern const unsigned short messi_title_image[38400];
#define MESSI_TITLE_IMAGE_SIZE 76800
#define MESSI_TITLE_IMAGE_LENGTH 38400
#define MESSI_TITLE_IMAGE_WIDTH 240
#define MESSI_TITLE_IMAGE_HEIGHT 160

#endif

