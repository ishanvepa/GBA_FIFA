/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 ronaldo ronaldo.png 
 * Time-stamp: Sunday 03/31/2024, 22:29:10
 * 
 * Image Information
 * -----------------
 * ronaldo.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RONALDO_H
#define RONALDO_H

extern const unsigned short ronaldo[625];
#define RONALDO_SIZE 1250
#define RONALDO_LENGTH 625
#define RONALDO_WIDTH 25
#define RONALDO_HEIGHT 25

#endif

