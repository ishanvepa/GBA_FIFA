/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 player_messi1 player_messi1.png 
 * Time-stamp: Tuesday 04/02/2024, 15:40:54
 * 
 * Image Information
 * -----------------
 * player_messi1.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_MESSI1_H
#define PLAYER_MESSI1_H

extern const unsigned short player_messi1[625];
#define PLAYER_MESSI1_SIZE 1250
#define PLAYER_MESSI1_LENGTH 625
#define PLAYER_MESSI1_WIDTH 25
#define PLAYER_MESSI1_HEIGHT 25

#endif

