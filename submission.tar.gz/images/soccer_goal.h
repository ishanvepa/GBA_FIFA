/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x27 soccer_goal soccer_goal.png 
 * Time-stamp: Sunday 03/31/2024, 01:52:14
 * 
 * Image Information
 * -----------------
 * soccer_goal.png 50@27
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SOCCER_GOAL_H
#define SOCCER_GOAL_H

extern const unsigned short soccer_goal[1350];
#define SOCCER_GOAL_SIZE 2700
#define SOCCER_GOAL_LENGTH 1350
#define SOCCER_GOAL_WIDTH 50
#define SOCCER_GOAL_HEIGHT 27

#endif

