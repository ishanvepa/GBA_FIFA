/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 soccer_field soccer_field.jpg 
 * Time-stamp: Sunday 03/31/2024, 01:51:12
 * 
 * Image Information
 * -----------------
 * soccer_field.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SOCCER_FIELD_H
#define SOCCER_FIELD_H

extern const unsigned short soccer_field[38400];
#define SOCCER_FIELD_SIZE 76800
#define SOCCER_FIELD_LENGTH 38400
#define SOCCER_FIELD_WIDTH 240
#define SOCCER_FIELD_HEIGHT 160

#endif

