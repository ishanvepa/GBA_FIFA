/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 referee referee.png 
 * Time-stamp: Tuesday 04/02/2024, 15:59:38
 * 
 * Image Information
 * -----------------
 * referee.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef REFEREE_H
#define REFEREE_H

extern const unsigned short referee[625];
#define REFEREE_SIZE 1250
#define REFEREE_LENGTH 625
#define REFEREE_WIDTH 25
#define REFEREE_HEIGHT 25

#endif

