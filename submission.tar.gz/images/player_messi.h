/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 player_messi player_messi.png 
 * Time-stamp: Sunday 03/31/2024, 21:35:27
 * 
 * Image Information
 * -----------------
 * player_messi.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_MESSI_H
#define PLAYER_MESSI_H

extern const unsigned short player_messi[625];
#define PLAYER_MESSI_SIZE 1250
#define PLAYER_MESSI_LENGTH 625
#define PLAYER_MESSI_WIDTH 25
#define PLAYER_MESSI_HEIGHT 25

#endif

