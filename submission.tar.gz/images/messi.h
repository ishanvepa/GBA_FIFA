/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 messi messi.png 
 * Time-stamp: Monday 04/01/2024, 00:15:08
 * 
 * Image Information
 * -----------------
 * messi.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MESSI_H
#define MESSI_H

extern const unsigned short messi[625];
#define MESSI_SIZE 1250
#define MESSI_LENGTH 625
#define MESSI_WIDTH 25
#define MESSI_HEIGHT 25

#endif

