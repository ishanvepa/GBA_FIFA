/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 gameover_lose gameover_lose.jpg 
 * Time-stamp: Sunday 03/31/2024, 21:51:50
 * 
 * Image Information
 * -----------------
 * gameover_lose.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEOVER_LOSE_H
#define GAMEOVER_LOSE_H

extern const unsigned short gameover_lose[38400];
#define GAMEOVER_LOSE_SIZE 76800
#define GAMEOVER_LOSE_LENGTH 38400
#define GAMEOVER_LOSE_WIDTH 240
#define GAMEOVER_LOSE_HEIGHT 160

#endif

