/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 win_world_cup win_world_cup.jpg 
 * Time-stamp: Sunday 03/31/2024, 22:36:00
 * 
 * Image Information
 * -----------------
 * win_world_cup.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_WORLD_CUP_H
#define WIN_WORLD_CUP_H

extern const unsigned short win_world_cup[38400];
#define WIN_WORLD_CUP_SIZE 76800
#define WIN_WORLD_CUP_LENGTH 38400
#define WIN_WORLD_CUP_WIDTH 240
#define WIN_WORLD_CUP_HEIGHT 160

#endif

