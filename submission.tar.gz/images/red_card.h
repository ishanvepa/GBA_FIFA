/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 red_card red_card.png 
 * Time-stamp: Tuesday 04/02/2024, 16:10:48
 * 
 * Image Information
 * -----------------
 * red_card.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RED_CARD_H
#define RED_CARD_H

extern const unsigned short red_card[38400];
#define RED_CARD_SIZE 76800
#define RED_CARD_LENGTH 38400
#define RED_CARD_WIDTH 240
#define RED_CARD_HEIGHT 160

#endif

