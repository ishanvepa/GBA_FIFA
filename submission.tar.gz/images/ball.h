/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 ball ball.png 
 * Time-stamp: Sunday 03/31/2024, 22:20:08
 * 
 * Image Information
 * -----------------
 * ball.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALL_H
#define BALL_H

extern const unsigned short ball[625];
#define BALL_SIZE 1250
#define BALL_LENGTH 625
#define BALL_WIDTH 25
#define BALL_HEIGHT 25

#endif

